def answar():
    return "42"